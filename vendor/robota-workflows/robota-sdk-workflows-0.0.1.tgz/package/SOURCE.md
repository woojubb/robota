Derived from woojubb/robota at bc88ec1219b1ebceb0329c781c4cb9bd8b0c9ff2.
Additional DAG schema/security synchronization: b190f44adc65bf8ab8f3cc98475c2a36a79b8248.
Host integration target: 8acad0d5e4cf400f348bf069abf53e0f7b01908a.
Next-release qualification recipe: official version command at Robota c11df7a83f4088f2df34e129f0a866153d7de186; evidence is separate from registry publication.
Corresponding source, tests, provenance and adaptations: https://github.com/robota-io/robota-workflows/tree/d324b16fcb9109b6569f60692290c29b3c5f8e7d
Source working tree: clean
Distribution retains AGPL-3.0-only OR LicenseRef-Commercial; no commercial grant is implied.
