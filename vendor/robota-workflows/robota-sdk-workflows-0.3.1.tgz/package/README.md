# Robota Workflows

A Node 22 library distributed as one private, installable tarball. Internal DAG packages are bundled, not separately
published. Use `@robota-sdk/workflows` for framework assembly, `/core` for domain contracts, `/node` for node authoring,
`/nodes` for the default catalog, `/builder` for persisted workflow decoding and `/command` for Robota command integration.
ESM, CommonJS and type declarations are supported. Robota SDKs are host-owned peers (`3.0.0-beta.102 || 3.0.0-beta.103 || 3.0.0-beta.104`). This Zod 4 contract does not support Zod 3 schema instances. Development bootstraps genuine SDK beta.102 source pinned to b190f44; isolated artifact consumption uses that source's complete SDK dependency closure as tarballs. The actual host rehearsal separately qualifies beta.103 at 8acad0d. Registry publication/consumption of either version has not been qualified.
A host must supply one shared SDK module instance. Robota integration uses ESM and verifies source/bundle loader identity.

The source workspace HTTP app is tested separately and is not a promised hosted service or part of this library API.
Provider-account calls, generic-engine portability and distributed exactly-once execution are not guarantees of this artifact.
See the repository's distribution/readiness documentation for tested behavior, release ordering and rollback.

The retained license is `AGPL-3.0-only OR LicenseRef-Commercial`; see LICENSE, LICENSING.md and COMMERCIAL.md.
A separate commercial grant is not implied. SOURCE.md identifies the corresponding source.

Candidate SDK beta.104 support requires qualification through an owned simulation of Robota's official release-version command from pinned source, not by manually relabeling SDK packages or assuming registry availability. The release qualification receipt records the consumer overlay and generated state separately.
