Derived from woojubb/robota at bc88ec1219b1ebceb0329c781c4cb9bd8b0c9ff2.
Additional DAG schema/security synchronization: b190f44adc65bf8ab8f3cc98475c2a36a79b8248.
Host integration target: 8acad0d5e4cf400f348bf069abf53e0f7b01908a.
Corresponding source, tests, provenance and adaptations: https://github.com/robota-io/robota-workflows/tree/6b7073f04f56586c8f516e83ec00c6f5af5c1c33
Source working tree: clean
Distribution retains AGPL-3.0-only OR LicenseRef-Commercial; no commercial grant is implied.
